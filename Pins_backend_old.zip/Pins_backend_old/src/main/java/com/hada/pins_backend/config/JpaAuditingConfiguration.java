package com.hada.pins_backend.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * Created by bangjinhyuk on 2021/08/27.
 */
@Configuration
@EnableJpaAuditing
public class JpaAuditingConfiguration {
}
