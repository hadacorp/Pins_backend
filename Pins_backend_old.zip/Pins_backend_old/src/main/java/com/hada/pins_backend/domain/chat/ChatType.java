package com.hada.pins_backend.domain.chat;

/**
 * Created by bangjinhyuk on 2021/12/20.
 */
public enum ChatType {
    ENTER,LEFT,MESSAGE,IMAGE,READ
}
