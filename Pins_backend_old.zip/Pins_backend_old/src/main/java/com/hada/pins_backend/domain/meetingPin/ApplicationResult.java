package com.hada.pins_backend.domain.meetingPin;

/**
 * Created by bangjinhyuk on 2021/12/05.
 */
public enum ApplicationResult {
    PROCEEDING, REJECTED
}
