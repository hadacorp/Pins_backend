package com.hada.pins_backend.dto.pin.response;

/**
 * Created by bangjinhyuk on 2021/12/05.
 */
public enum MeetingPinStatus {
    REQUESTED, REJECTED, OPEN, CLOSED, MANAGE, PARTICIPATED
}
