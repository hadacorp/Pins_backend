package com.hada.pins_backend.advice.home;

/**
 * Created by bangjinhyuk on 2021/09/25.
 */
public class PintypeDBIdException extends RuntimeException{
}
