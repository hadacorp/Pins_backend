package com.hada.pins_backend.advice.user;

/**
 * Created by bangjinhyuk on 2021/08/27.
 */
public class NotExistException extends RuntimeException {
}
