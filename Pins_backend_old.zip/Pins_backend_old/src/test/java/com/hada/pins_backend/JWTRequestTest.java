package com.hada.pins_backend;

import com.hada.pins_backend.domain.user.User;
import com.hada.pins_backend.dto.user.UserLoginForm;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestTemplate;

/**
 * Created by bangjinhyuk on 2021/08/08.
 */
public class JWTRequestTest{

    @Test
    void Test(){

    }
}
